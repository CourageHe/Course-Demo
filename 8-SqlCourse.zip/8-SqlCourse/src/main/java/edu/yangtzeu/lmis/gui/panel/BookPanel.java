package edu.yangtzeu.lmis.gui.panel;

import javax.swing.JPanel;

public class BookPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public BookPanel() {

	}

}
