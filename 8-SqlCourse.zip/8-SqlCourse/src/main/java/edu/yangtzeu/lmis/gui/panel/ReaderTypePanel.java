package edu.yangtzeu.lmis.gui.panel;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ReaderTypePanel extends JPanel {

	private JTextField rdNameField;
	/**
	 * Create the panel.
	 */
	public ReaderTypePanel() {
		//查询条件
		JPanel searchPanel = new JPanel();
		searchPanel.setBounds(0, 0, 1040, 34);
		searchPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("读者类别：");
		lblNewLabel.setBounds(46, 9, 75, 18);
		searchPanel.add(lblNewLabel);
		
		JComboBox rdTypeComboBox = new JComboBox();
		rdTypeComboBox.setBounds(149, 6, 74, 24);
		searchPanel.add(rdTypeComboBox);
		rdTypeComboBox.setModel(new DefaultComboBoxModel(new String[] {"教师", "本科生", "研究生", "博士"}));
		
		JLabel label = new JLabel("单位：");
		label.setBounds(281, 9, 45, 18);
		searchPanel.add(label);
		
		JComboBox deptTypeComboBox = new JComboBox();
		deptTypeComboBox.setBounds(340, 6, 149, 24);
		searchPanel.add(deptTypeComboBox);
		deptTypeComboBox.setModel(new DefaultComboBoxModel(new String[] {"计算机科学与技术", "软件工程", "物联网工程", "网络工程"}));
		
		JLabel label_1 = new JLabel("姓名：");
		label_1.setBounds(523, 9, 45, 18);
		searchPanel.add(label_1);
		
		rdNameField = new JTextField();
		rdNameField.setBounds(569, 6, 163, 24);
		searchPanel.add(rdNameField);
		rdNameField.setColumns(10);
		
		JButton btnQuery = new JButton("查找");
		btnQuery.setBounds(787, 5, 63, 27);
		searchPanel.add(btnQuery);
		
		JButton btnToExcel = new JButton("Excel");
		btnToExcel.setBounds(864, 5, 73, 27);
		searchPanel.add(btnToExcel);
		
		
		//查询结果
		JPanel searchResultPanel = new JPanel();
		searchResultPanel.setBounds(0, 66, 708, 547);
		searchResultPanel.setLayout(null);
		JTable searchResultJTable = new JTable();
		searchResultJTable.setBounds(0, 13, 708, 534);
		searchResultJTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"ID", "\u59D3\u540D", "\u6027\u522B", "\u7C7B\u578B", "\u9662\u7CFB", "\u7535\u8BDD", "Email", "\u72B6\u6001", "\u5DF2\u501F\u6570\u76EE", "\u6CE8\u518C\u65E5\u671F"
			}
		));
		searchResultPanel.add(searchResultJTable);
	}

}
