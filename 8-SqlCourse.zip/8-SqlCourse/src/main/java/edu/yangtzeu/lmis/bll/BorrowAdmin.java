package edu.yangtzeu.lmis.bll;

public class BorrowAdmin {

}
