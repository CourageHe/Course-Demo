package edu.yangtzeu.lmis.bll;

public class UserAdmin {

}
