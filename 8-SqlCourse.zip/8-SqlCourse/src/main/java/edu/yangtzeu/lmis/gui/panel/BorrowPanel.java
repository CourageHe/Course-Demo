package edu.yangtzeu.lmis.gui.panel;

import javax.swing.JPanel;

public class BorrowPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public BorrowPanel() {

	}

}
