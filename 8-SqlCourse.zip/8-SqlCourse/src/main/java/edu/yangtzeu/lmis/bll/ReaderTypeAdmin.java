package edu.yangtzeu.lmis.bll;

import edu.yangtzeu.lmis.dal.ReaderTypeDAL;
import edu.yangtzeu.lmis.model.ReaderType;

public class ReaderTypeAdmin {
	private ReaderTypeDAL dal = new ReaderTypeDAL();
	
	public ReaderType[] getReaderTypes() {
		try {
			return (ReaderType[])dal.getAllObjects();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return null;
	}
}
