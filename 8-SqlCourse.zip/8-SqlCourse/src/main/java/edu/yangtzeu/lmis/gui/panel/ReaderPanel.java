package edu.yangtzeu.lmis.gui.panel;

import javax.imageio.ImageIO;
import javax.naming.InitialContext;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.omg.CORBA.PRIVATE_MEMBER;

import edu.yangtzeu.lmis.bll.ReaderAdmin;
import edu.yangtzeu.lmis.bll.ReaderTypeAdmin;
import edu.yangtzeu.lmis.model.CustomizedTableModel;
import edu.yangtzeu.lmis.model.DepartMentType;
import edu.yangtzeu.lmis.model.Reader;
import edu.yangtzeu.lmis.model.ReaderType;

import java.awt.BorderLayout;
import javax.swing.border.CompoundBorder;
import javax.swing.filechooser.FileFilter;

import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class ReaderPanel extends JPanel {
	private JTextField tfUserName;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	
	private JTable searchResultJTable;
	private JLabel lblPhoto;
	private JComboBox rdTypeComboBox;
	private JComboBox deptTypeComboBox;


	private JPanel searchPanel ;
	private JPanel searchResultPanel;
	private JPanel readerInfoPanel;
	private JPanel functionCtrlPanel;
	private JPanel editCtrlPanel ;

	private JButton btnAddReader;
	private JButton btnSubmitUpdate;
	private JButton btnCancelEdit;
	private JButton  btnClose;
	private JButton  btnCancelReader;
	private JButton  btnFound;
	private JButton  btnLost;
	private JButton  btnUpdateReader;
	private JButton  btnNewReader;
	private JButton btnLoadPictureFile;
	private JButton btnQuery;
	private JButton btnToExcel;

	private ReaderTypeAdmin readerTypeBll = new ReaderTypeAdmin();
	private ReaderAdmin readerBll = new ReaderAdmin();
	
	private String[]dispColNames = new String[] {"ID","姓名","性别","类型","院系","电话","Email","状态","已借书数量","注册日期"};
	private String[] methodNames = new String[] {"getRdID","getRdName","getRdSex","getRdType","getRdDept","getRdPhone","getRdEmail","getRdStatus","getRdBorrowQty","getRdDateReg"};
	//示3种窗口操作状态
	private enum OpStatus{inSelect ,inNew,inChange};
	private OpStatus ops;
	private void setStatus(OpStatus opst) {
		ops = opst;
		switch(ops) {
		case inSelect:		
			searchPanel.setEnabled(true); ;
			searchResultPanel.setEnabled(true);;
			functionCtrlPanel.setEnabled(true);;
			
			this.setComponentStatusInPanel(functionCtrlPanel,true);
			
			readerInfoPanel.setEnabled(false);
			readerInfoPanel.setVisible(false);
			editCtrlPanel.setEnabled(false) ;
			editCtrlPanel.setVisible(false);
			this.setComponentStatusInPanel(editCtrlPanel,false);
			break;
		case inNew:
			searchPanel.setEnabled(false); ;
			searchResultPanel.setEnabled(false);;
			functionCtrlPanel.setEnabled(false);;
			
			this.setComponentStatusInPanel(functionCtrlPanel,false);
			
			readerInfoPanel.setEnabled(true);
			readerInfoPanel.setVisible(true);
			editCtrlPanel.setEnabled(true) ;
			editCtrlPanel.setVisible(true);
			this.setComponentStatusInPanel(editCtrlPanel,true);
			btnSubmitUpdate.setEnabled(false);
			
			break;
		case inChange:
			searchPanel.setEnabled(false); ;
			searchResultPanel.setEnabled(false);;
			functionCtrlPanel.setEnabled(false);;
			
			this.setComponentStatusInPanel(functionCtrlPanel,false);
			
			readerInfoPanel.setEnabled(true);
			readerInfoPanel.setVisible(true);
			editCtrlPanel.setEnabled(true) ;
			editCtrlPanel.setVisible(true);
			this.setComponentStatusInPanel(editCtrlPanel,true);
			btnAddReader.setEnabled(false);
			break;
		}
	}
	/**
	 * 开启或关闭面板内的所有组件
	 * @param panel
	 * @param status
	 */
	private void setComponentStatusInPanel(JPanel panel,boolean status) {
		for(Component comp:panel.getComponents()) {
			comp.setEnabled(status);
		}
		
	}
	public ReaderPanel() {
		setLayout(null);
		//初始化各个Panel
		initSearchPanel();
		initSearchResultPanel();
		initReaderInfoPanel();
		initFunctionControlsPanel();
		initEditControlsSearchPanel();
		//设置初始操作状态
		setStatus(OpStatus.inSelect);
		//添加动作监听器
		initListener();
	}
	private void initSearchPanel() {
		//查询条件
				searchPanel = new JPanel();
				searchPanel .setBounds(0, 0, 1040, 34);
				searchPanel.setLayout(null);
				add(searchPanel);
				
				JLabel lblNewLabel = new JLabel("读者类别：");
				lblNewLabel.setBounds(46, 9, 75, 18);
				searchPanel.add(lblNewLabel);
				
				rdTypeComboBox = new JComboBox/*<ReaderType>*/(readerTypeBll.getReaderTypes());
				rdTypeComboBox.setBounds(149, 6, 74, 24);
				searchPanel.add(rdTypeComboBox);
//				rdTypeComboBox.setModel(new DefaultComboBoxModel(new String[] {"教师", "本科生", "研究生", "博士"}));
				
				JLabel label = new JLabel("单位：");
				label.setBounds(281, 9, 45, 18);
				searchPanel.add(label);
				
				deptTypeComboBox = new JComboBox();
				deptTypeComboBox.setBounds(340, 6, 149, 24);
				searchPanel.add(deptTypeComboBox);
				deptTypeComboBox.setModel(new DefaultComboBoxModel(new String[] {"计算机科学与技术", "软件工程", "物联网工程", "网络工程"}));
				
				JLabel label_1 = new JLabel("姓名：");
				label_1.setBounds(523, 9, 45, 18);
				searchPanel.add(label_1);
				
				tfUserName = new JTextField();
				tfUserName.setBounds(569, 6, 163, 24);
				searchPanel.add(tfUserName);
				tfUserName.setColumns(10);
				
				btnQuery = new JButton("查找");
				
				btnQuery.setBounds(793, 5, 63, 27);
				searchPanel.add(btnQuery);
				
				btnToExcel = new JButton("Excel");
			
				btnToExcel.setBounds(864, 5, 73, 27);
				searchPanel.add(btnToExcel);
	}
	private void initSearchResultPanel() {
		//查询结果
		searchResultPanel = new JPanel();
		searchResultPanel.setBounds(0, 59, 708, 547);
		add(searchResultPanel);
		searchResultPanel.setLayout(new BorderLayout(0, 0));
		JScrollPane searchResultScroll = new JScrollPane();
		searchResultScroll.setToolTipText("查询结果");
		searchResultPanel.add(searchResultScroll, BorderLayout.CENTER);
		
//				JTable searchResultJTable = new JTable();
//				searchResultScroll.setViewportView(searchResultJTable);
//				searchResultJTable.setModel(new DefaultTableModel(
//					new Object[][] {
//					},
//					dispColNames
//				));
				CustomizedTableModel<Reader>tableModel = new CustomizedTableModel<Reader>(readerBll.getDisplayColumnNames(), readerBll.getMethodNames());
				searchResultJTable = new JTable(tableModel);
				searchResultScroll.setViewportView(searchResultJTable);
	}
	private void initReaderInfoPanel() {
		readerInfoPanel = new JPanel();
		readerInfoPanel.setToolTipText("");
		readerInfoPanel.setBounds(740, 58, 377, 548);
		add(readerInfoPanel);
		readerInfoPanel.setLayout(null);
		
		JLabel label_2 = new JLabel("借书证号");
		label_2.setBounds(14, 16, 60, 18);
		readerInfoPanel.add(label_2);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(88, 13, 116, 24);
		textField.setColumns(10);
		readerInfoPanel.add(textField);
		
		JLabel label_3 = new JLabel("姓名");
		label_3.setBounds(14, 56, 60, 18);
		readerInfoPanel.add(label_3);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(88, 53, 116, 24);
		readerInfoPanel.add(textField_1);
		
		JLabel label_4 = new JLabel("密码");
		label_4.setBounds(14, 96, 60, 18);
		readerInfoPanel.add(label_4);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(88, 93, 116, 24);
		readerInfoPanel.add(textField_2);
		
		JLabel label_5 = new JLabel("性别");
		label_5.setBounds(14, 136, 60, 18);
		readerInfoPanel.add(label_5);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(88, 133, 116, 24);
		readerInfoPanel.add(textField_3);
		
		JLabel label_6 = new JLabel("已借书……");
		label_6.setBounds(14, 176, 60, 18);
		readerInfoPanel.add(label_6);
		
		textField_4 = new JTextField();
		textField_4.setEditable(false);
		textField_4.setColumns(10);
		textField_4.setBounds(88, 173, 116, 24);
		readerInfoPanel.add(textField_4);
		
		JLabel label_7 = new JLabel("证件状态");
		label_7.setBounds(14, 216, 60, 18);
		readerInfoPanel.add(label_7);
		
		textField_5 = new JTextField();
		textField_5.setEditable(false);
		textField_5.setColumns(10);
		textField_5.setBounds(88, 213, 116, 24);
		readerInfoPanel.add(textField_5);
		
		JLabel label_8 = new JLabel("读者角色");
		label_8.setBounds(14, 256, 60, 18);
		readerInfoPanel.add(label_8);
		
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setColumns(10);
		textField_6.setBounds(88, 253, 116, 24);
		readerInfoPanel.add(textField_6);
		
		lblPhoto = new JLabel("");
		lblPhoto.setBounds(218, 13, 145, 264);
		lblPhoto.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		readerInfoPanel.add(lblPhoto);
		
		btnLoadPictureFile = new JButton("图片文件");
	
		btnLoadPictureFile.setBounds(228, 294, 113, 27);
		readerInfoPanel.add(btnLoadPictureFile);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(88, 293, 116, 24);
		readerInfoPanel.add(comboBox);
		
		JLabel label_10 = new JLabel("读者类别");
		label_10.setBounds(14, 298, 60, 18);
		readerInfoPanel.add(label_10);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(88, 333, 169, 24);
		readerInfoPanel.add(comboBox_1);
		
		JLabel label_11 = new JLabel("单位");
		label_11.setBounds(14, 335, 60, 18);
		readerInfoPanel.add(label_11);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(88, 373, 169, 24);
		readerInfoPanel.add(textField_7);
		
		JLabel lable_l = new JLabel("姓名");
		lable_l.setBounds(14, 377, 60, 18);
		readerInfoPanel.add(lable_l);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(88, 413, 169, 24);
		readerInfoPanel.add(textField_8);
		
		JLabel label_12 = new JLabel("电子邮件");
		label_12.setBounds(14, 414, 60, 18);
		readerInfoPanel.add(label_12);
		
		textField_9 = new JTextField();
		textField_9.setEditable(false);
		textField_9.setColumns(10);
		textField_9.setBounds(88, 453, 169, 24);
		readerInfoPanel.add(textField_9);
		
		JLabel label_13 = new JLabel("办证日期");
		label_13.setBounds(14, 451, 60, 18);
		readerInfoPanel.add(label_13);
		
		//用于显示读者的历史借阅记录数和未归还图书数量。
		JLabel lblBorrowInfo = new JLabel("");
		lblBorrowInfo.setBounds(24, 490, 233, 18);
		readerInfoPanel.add(lblBorrowInfo);
		
		JLabel searchLabel = new JLabel("查询结果");
		searchLabel.setBounds(0, 40, 72, 18);
		add(searchLabel);
		
		JLabel readerLabel = new JLabel("读者信息");
		readerLabel.setBounds(740, 40, 72, 18);
		add(readerLabel);
	}
	
	private void initFunctionControlsPanel() {
		functionCtrlPanel = new JPanel();
		functionCtrlPanel.setBounds(0, 634, 708, 34);
		add(functionCtrlPanel);
		
		btnNewReader = new JButton("办理借书证");
		
		functionCtrlPanel.add(btnNewReader);
		
		btnUpdateReader = new JButton("变更信息");
		
		functionCtrlPanel.add(btnUpdateReader);
		
		btnLost = new JButton("挂失");
		functionCtrlPanel.add(btnLost);
		
		btnFound = new JButton("解除挂失");
		functionCtrlPanel.add(btnFound);
		
		btnCancelReader = new JButton("注销");
		functionCtrlPanel.add(btnCancelReader);
		
		btnClose = new JButton("退出");
		functionCtrlPanel.add(btnClose);
		
		
	}
	private void initEditControlsSearchPanel() {
		editCtrlPanel = new JPanel();
		editCtrlPanel.setBounds(740, 634, 377, 34);
		add(editCtrlPanel);
		
		btnAddReader = new JButton("确认办证");
	
		editCtrlPanel.add(btnAddReader);
		
		btnSubmitUpdate = new JButton("确认变更");
	
		editCtrlPanel.add(btnSubmitUpdate);
		
		btnCancelEdit = new JButton("取消");
		
		editCtrlPanel.add(btnCancelEdit);
	}
	/**
	 * 添加监听事件，进行状态切换
	 */
	private void initListener() {
		
		btnNewReader.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setStatus(OpStatus.inNew);
			}
		});
		
		btnUpdateReader.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setStatus(OpStatus.inChange);
			}
		});
		btnCancelEdit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setStatus(OpStatus.inSelect);
			}
		});
		//?确认办证、确认变更的Click事件该如何切换状态？
		
		
		btnAddReader.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		btnSubmitUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		btnLoadPictureFile.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				JFileChooser fc = new JFileChooser();
				fc.addChoosableFileFilter(new FileFilter() {

				    public boolean accept(File f) {
				        String name = f.getName().toLowerCase();
				        return (name.endsWith(".png") &&
				                        name.endsWith(".jpg") &&
				                        name.endsWith(".gif") &&
				                        name.endsWith(".bmp") &&
				                        f.length() < 3 * (1024 * 1024));
				    }

				    public String getDescription() {
				        return "Images < 3mb";
				    }
				});
				int returnVal = fc.showOpenDialog(ReaderPanel.this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					BufferedImage img;
					try {
						img = ImageIO.read(file);
						Image dimg = img.getScaledInstance(lblPhoto.getWidth(), lblPhoto.getHeight(), Image.SCALE_SMOOTH);
						ImageIcon icon = new ImageIcon(dimg);
					} catch (IOException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
				}
			}
		});
		btnQuery.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				ReaderType rdType = (ReaderType)rdTypeComboBox.getSelectedItem();
				DepartMentType deptType = (DepartMentType)deptTypeComboBox.getSelectedItem();
				String userName = tfUserName.getText().trim();
				Reader[]hits = readerBll.retrieveReaders(rdType, deptType, userName);
				//更新查询结果
				updateResultTable(hits);
			}
		});
		
		//实现excel导出
		btnToExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
	}
	public void updateResultTable(Reader[]readers){
		if(readers == null) {
			JOptionPane.showMessageDialog(null,"没有找到符合要求的记录");
			return;
		}
		CustomizedTableModel<Reader>tableModel = (CustomizedTableModel<Reader>)searchResultJTable.getModel();
		tableModel.setRecords(readers);
		//更新数据
		tableModel.fireTableDataChanged();
	}
	public static void main(String[]args) {
		ReaderPanel readerPanel = new ReaderPanel();
		readerPanel.setVisible(true);
	}
	
}

//https://blog.csdn.net/wangxiaojingo/article/details/8927170 JLable的使用方法
