package edu.yangtzeu.lmis.model;
/**
 * 
 * @author CourageHe
 *
 */
public class DepartMentType {

}
