package edu.yangtzeu.lmis.bll;

import edu.yangtzeu.lmis.dal.ReaderDAL;
import edu.yangtzeu.lmis.model.DepartMentType;
import edu.yangtzeu.lmis.model.Reader;
import edu.yangtzeu.lmis.model.ReaderType;

public class ReaderAdmin extends LibraryBLL{
	private ReaderDAL dal= new ReaderDAL();
	
	public ReaderAdmin() {
//		dal= new ReaderDAL();
	}
	//系统根据借书证号获取读者对象
	public Reader getReader(int rdID) {
		try {
			return (Reader)dal.getObjectByID(rdID);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public
	Reader[]retrieveReaders(ReaderType rdType,DepartMentType deptType,String userName){
		return dal.getReadersBy(rdType,deptType,userName);
	}
}
