package edu.yangtzeu.lmis.bll;

public class BookAdmin {

}
