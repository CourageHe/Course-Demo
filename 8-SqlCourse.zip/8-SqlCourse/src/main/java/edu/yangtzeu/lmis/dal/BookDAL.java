package edu.yangtzeu.lmis.dal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.yangtzeu.lmis.model.AbstractModel;
import edu.yangtzeu.lmis.model.Book;
import edu.yangtzeu.lmis.model.ReaderType;

public class BookDAL extends  AbstractDAL{
	@Override
	public AbstractModel[] getAllObjects() throws Exception {
		ArrayList<Book>objects = new ArrayList<Book>();
		ResultSet rs = SQLHelper.getResultSet("SELECT * FROM TB_Book",null);
		if(rs != null) {
			while (rs.next()) {
				Book ld = initBook(rs);
				objects.add(ld);
			}
			rs.close();
		}
		//列表转为数组实现动态装载
		Book[]Books =new Book[objects.size()];
		objects.toArray(Books);
		return Books;
	}

	@Override
	public int add(AbstractModel object) throws Exception {
		if(object instanceof Book ==false) {
			throw new Exception("Can Only Handl Book");
		}
		Book bk= (Book)object;
		String  sql = "INSERT INTO TB_Book(bkID,bkCode,bkName,bkAuthor,bkPress,bkDatePress,bkISBN,bkCatalog,bkLanguage,bkPrice,bkPages,bkDateIn,bkBrief,bkCover,bkStatus)"
						+"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[]params= new Object[15];
		params[0] = bk.getBkID();
		params[1] = bk.getBkCode();
		params[2] = bk.getBkName();
		params[3] = bk.getBkAuthor();
		params[4] = bk.getBkPress();
		String datePress = SQLHelper.formaDatetime(bk.getBkDatePress());
		params[5] = datePress;
		params[6] =bk.getBkISBN();
		params[7] = bk.getBkCatalog();
		params[8] = bk.getBkLanguage();
		params[9] = bk.getBkPrice();
		params[10] = bk.getBkPages();
		String dateIn = SQLHelper.formaDatetime(bk.getBkDateIn());
		params[11] = dateIn;
		params[12] = bk.getBkBrief();
		params[13] = bk.getBkCover();
		params[14] = bk.getBkStatus();
		return SQLHelper.ExecSql(sql, params);
	}

	@Override
	public int delete(AbstractModel object) throws Exception {
		if(object instanceof Book ==false) {
			throw new Exception("Can Only Handl Book");
		}
		Book bk= (Book)object;
		String  sql = "DELETE FROM TB_Book WHERE bkID=?";
		Object[]params= new Object[] {bk.getBkID()};
		return SQLHelper.ExecSql(sql, params);
	}

	@Override
	public int update(AbstractModel object) throws Exception {
		if(object instanceof Book ==false) {
			throw new Exception("Can Only Handl Book");
		}
		Book bk = (Book)object;
		String  sql = "UPDATE TB_Book SET bkCode=?,bkName=?,bkAuthor=?,bkPress=?,bkDatePress=?,bkISBN=?,bkCatalog=?,bkLanguage=?,bkPrice=?,bkPages=?,bkDateIn=?,bkBrief=?,bkCover=?,bkStatus=? WHERE  bkID=?";
		String datePress = SQLHelper.formaDatetime(bk.getBkDatePress());
		String dateIn = SQLHelper.formaDatetime(bk.getBkDateIn());
		Object[]params= new Object[] {bk.getBkCode() ,bk.getBkName(),bk.getBkAuthor(),bk.getBkPress(),datePress,bk.getBkISBN(),bk.getBkCatalog(),bk.getBkLanguage(),bk.getBkPrice(),bk.getBkPages(),dateIn ,bk.getBkBrief(),bk.getBkCover(),bk.getBkStatus(),bk.getBkID()};
		return SQLHelper.ExecSql(sql, params);
	}

	@Override
	public AbstractModel getObjectByID(int bkID) throws Exception {
		Book bk= null;
		String sql = "SELECT bkID,bkCode,bkName,bkAuthor,bkPress,bkDatePress,bkISBN,bkCatalog,bkLanguage,bkPrice,bkPages,bkDateIn,bkBrief,bkCover,bkStatus FROM TB_Book WHERE bkID="+bkID;
		Object[]params = new Object[]{bkID};
		ResultSet rs = SQLHelper.getResultSet(sql,params);
		if(rs.next()) {
			bk= initBook(rs);
		}
		rs.close();
		return bk;
	}
	/**
	 * 初始化BookType
	 * @param rs
	 * @return
	 * @throws SQLException 
	 */
	private Book initBook(ResultSet rs) throws SQLException {
		Book bk= new Book();

		bk.setBkID(rs.getInt("bkID"));
		bk.setBkCode(rs.getString("bkCode"));
		//日期可能需要特别处理
		bk.setBkName(rs.getString("bkName"));
		bk.setBkAuthor(rs.getString("bkAuthor"));
		bk.setBkPress(rs.getString("bkPress"));
		bk.setBkDatePress(rs.getDate("bkDatePress"));
		bk.setBkISBN(rs.getString("bkISBN"));
		bk.setBkCatalog(rs.getString("bkCatalog"));
		bk.setBkLanguage(rs.getInt("bkLanguage"));
		bk.setBkPrice(rs.getFloat("bkPrice"));
		bk.setBkPages(rs.getInt("bkPages"));
		bk.setBkDateIn(rs.getDate("bkDateIn"));
		bk.setBkBrief(rs.getString("bkBrief"));
		bk.setBkCover(rs.getBytes("bkCover"));
		bk.setBkStatus(rs.getString("bkStatus"));

		return bk;
		
	}
	@Override
	public String[] getPrettyColumnNames() throws Exception {
		// TODO 自动生成的方法存根
		return null;
	}

	@Override
	public String[] getMethodNames() throws Exception {
		// TODO 自动生成的方法存根
		return null;
	}

}
